# Kavita

Kavita, a reader for comics, manga and books in the browser and in e-reader apps (OPDS). It reads your books and comics folders and never changes them.

An app plug-in for Starboard (plug-in API 1.13): Kavita runs outside the main install, in Starboard's locked-down
containers, with its own page on your home network. Starboard chooses the port (5000 when it is free) and shows the address
on the plug-in's page with **Open**.

## Who it is for

People who read comics, manga and books, in the browser or in an e-reader app that speaks OPDS. The main install can also add Kavita (Install apps, Ebooks); use one or the other.

## Set it up

1. Activate it, choose **Open Kavita** and make the first account, which is its admin.
2. Add libraries for `/media/books` and `/media/comics`. It reads them only, so Kavita cannot change or delete a file. Its sign-in key is made for this install.

## What it may do

- It can see: Files in your media folder under books (read only).
- It can see: Files in your media folder under comics (read only).
- It can change: Its own folder in Starboard's data (data/plugins/kavita).
- It can reach: Other computers on your home network, and the internet.
- It can reach: Its own web page is opened on your home network: anyone on your home network can open it, at this computer's address and a port Starboard chooses.

It runs read only, as a user that is not root, with no extra rights, like every plug-in. Its images, pinned by digest:

- `app`: `docker.io/jvmilazz0/kavita@sha256:31181a32f0dda73cae68721867028a7253d57881b58bea5754cd9e578e75421a`

## At rest

What it uses when nobody is using it, measured with `tools/app_check.py` (median of 36 readings over 3 minutes, after
2 minutes to settle). A real library uses more.

| Reading | Memory | Processor (one core) |
|---|---|---|
| As Starboard runs it (hardened, empty library), 13 November 2026 | 339.1 MiB | 0.77% |
| 13 November benchmark (`bench-2026-11-13/RESULTS.md`, no limits) | 337.4 MiB | 0.99% |

## Removing it

**Settings**, **Plug-ins**, Kavita, **Remove**. Its containers stop and go and its key stops working. You choose
where its folder goes, with everything it kept (settings):
kept in `data/plugins/.removed`, or moved to the holding folder in **System**, **Clean up**, from where you can put it
back or delete it for good. Starboard never deletes it. Your media folder is not touched.

## Licence

This plug-in is MIT, by TheMightyTRexUK. Kavita itself is under the GPL-3.0 licence, made by others: https://www.kavitareader.com
