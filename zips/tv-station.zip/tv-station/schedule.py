"""The schedule: what each channel shows at any moment, worked out from time, never stored or streamed.

The idea comes from Clickarr (github.com/thegregstengel/clickarr, MIT): a channel is a function from time to
programme. Its inputs are small and kept: a frozen line-up (each programme and how long it runs), the time the
line-up started, and a seed. With the same inputs, every question about the same moment gets the same answer, so
the guide, the dashboard card and the stream always agree, and nothing runs between viewings. No code is copied.

A channel has eras. An era is one line-up from a moment on. When the line-up changes (new episodes, or the owner
changes what the channel shows), a new era starts at the end of the programme on air then, carrying on from the
programme that would have come next, so the channel never jumps part way through a programme.

Times are seconds since 1970 (UTC). Local time is used only for words people read.
"""
import bisect
import hashlib
import math

SCHEDULER_VERSION = 1
MASK = (1 << 64) - 1
CARD_SECONDS = 10  # one Coming up next or Later card
CARD_MAX = 20  # the longest one card stays on screen
MIN_PIECE = 1.0  # a gap shorter than this is left as a short pause at the end of the programme


# A small random number generator of our own (SplitMix64), so a shuffle is the same on every computer and every
# Python version, which random.Random does not promise.
class Rng:
    def __init__(self, seed):
        self.state = int(seed) & MASK

    def next(self):
        self.state = (self.state + 0x9E3779B97F4A7C15) & MASK
        z = self.state
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & MASK
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & MASK
        return z ^ (z >> 31)

    def below(self, n):
        return self.next() % n if n > 0 else 0


def seed_of(*parts):
    """A 64-bit number from any values, the same everywhere."""
    h = hashlib.sha256("\x1f".join(str(p) for p in parts).encode()).digest()
    return int.from_bytes(h[:8], "big")


def shuffled(items, seed):
    out = list(items)
    rng = Rng(seed)
    for i in range(len(out) - 1, 0, -1):
        j = rng.below(i + 1)
        out[i], out[j] = out[j], out[i]
    return out


def group_runs(entries, run):
    """Each series' episodes in their order, cut into runs of `run` in a row. A film is a run of its own."""
    groups, order = {}, []
    for i, e in enumerate(entries):
        g = e.get("group") or e["id"]
        if g not in groups:
            groups[g] = []
            order.append(g)
        groups[g].append(i)
    n = max(1, int(run or 1))
    return [[groups[g][k:k + n] for k in range(0, len(groups[g]), n)] for g in order]


def cycle_order(entries, order, run, seed, cycle):
    """The order of the line-up's programmes in one cycle, as positions in `entries`.
    In order: each series' runs in turn (A1 A2, B1 B2, A3 A4 ...). Shuffled: the runs in a new order each cycle."""
    groups = group_runs(entries, run)
    if order == "shuffle":
        runs = [r for g in groups for r in g]
        return [i for r in shuffled(runs, seed_of(seed, cycle)) for i in r]
    out, k = [], 0
    while True:
        took = False
        for g in groups:
            if k < len(g):
                out.extend(g[k])
                took = True
        if not took:
            return out
        k += 1


def slot_length(duration, start_on, break_seconds=0):
    """How long a programme's slot is. Back to back (start_on 0): the programme and the break after it. On the
    quarter, half or whole hour (15, 30 or 60): rounded up to the next one, and the break fills the rest."""
    need = max(1.0, float(duration)) + max(0, int(break_seconds or 0))
    if not start_on:
        return need
    grid = int(start_on) * 60
    return float(math.ceil(need / grid - 1e-9) * grid)


def floor_to(t, start_on):
    if not start_on:
        return float(int(t))
    grid = int(start_on) * 60
    return float(int(t // grid) * grid)


class Era:
    """One line-up from `start` on. `skip` is how many programmes of the first cycle are passed over, so a new era
    carries on where the one before it was."""

    def __init__(self, spec):
        self.start = float(spec["from"])
        self.entries = spec.get("lineup") or []
        self.seed = spec.get("seed", 0)
        self.order = spec.get("order", "in_order")
        self.run = int(spec.get("run") or 1)
        self.start_on = int(spec.get("start_on") or 0)
        self.break_seconds = int(spec.get("break_seconds") or 0)
        self.skip = int(spec.get("skip") or 0)
        self.slots = [slot_length(e["dur"], self.start_on, self.break_seconds) for e in self.entries]
        self.length = sum(self.slots)
        self._cache = {}

    def _cycle(self, cycle):
        got = self._cache.get(cycle)
        if got is None:
            order = cycle_order(self.entries, self.order, self.run, self.seed, cycle)
            sums, t = [], 0.0
            for i in order:
                sums.append(t)
                t += self.slots[i]
            got = (order, sums)
            if len(self._cache) > 8:
                self._cache.clear()
            self._cache[cycle] = got
        return got

    def offset0(self):
        if not self.entries:
            return 0.0
        order, sums = self._cycle(0)
        return sums[self.skip % len(order)] if order else 0.0

    def airing(self, t):
        """The programme in its slot at time t: a dict, or None before the era or with an empty line-up."""
        if not self.entries or self.length <= 0 or t < self.start:
            return None
        e = (t - self.start) + self.offset0()
        cycle = int(e // self.length)
        within = e - cycle * self.length
        order, sums = self._cycle(cycle)
        pos = bisect.bisect_right(sums, within) - 1
        slot_start = t - (within - sums[pos])
        idx = order[pos]
        entry = self.entries[idx]
        dur = float(entry["dur"])
        end = slot_start + self.slots[idx]
        return {"entry": entry, "start": slot_start, "content_end": min(slot_start + dur, end), "end": end,
                "cycle": cycle, "pos": pos, "slot_no": cycle * len(order) + pos}

    def next_entry_id(self, t):
        """The programme that follows the one on air at t."""
        a = self.airing(t)
        if not a:
            return None
        nxt = self.airing(a["end"])
        return nxt["entry"]["id"] if nxt else None


class Channel:
    """A channel's eras, from its kept settings: {"eras": [...], ...}."""

    def __init__(self, spec):
        self.spec = spec
        self.eras = sorted((Era(e) for e in spec.get("eras") or []), key=lambda e: e.start)
        self._starts = [e.start for e in self.eras]

    def era_at(self, t):
        i = bisect.bisect_right(self._starts, t) - 1
        return self.eras[i] if i >= 0 else None

    def airing(self, t):
        era = self.era_at(t)
        a = era.airing(t) if era else None
        if a is None:
            return None
        # A later era cuts this slot short only if it starts inside it (it never does when made by new_era).
        i = self.eras.index(era)
        if i + 1 < len(self.eras) and self.eras[i + 1].start < a["end"]:
            a["end"] = self.eras[i + 1].start
            a["content_end"] = min(a["content_end"], a["end"])
        return a

    def airings(self, start, stop, limit=2000):
        """Every slot that overlaps [start, stop), in order."""
        out, t = [], float(start)
        while t < stop and len(out) < limit:
            a = self.airing(t)
            if a is None:
                era = next((e for e in self.eras if e.start > t), None)
                if not era:
                    break
                t = era.start
                continue
            out.append(a)
            t = a["end"] if a["end"] > t else t + 1
        return out


def new_era(spec, lineup, now, settings_changed=False):
    """The channel's eras with a new line-up starting at the end of the programme on air at `now` (or at once, on the
    next boundary, when nothing is on). Carries on from the programme that would have come next when it is still in
    the new line-up. Returns the new list of eras; drops the ones that ended over a day ago."""
    ch = Channel(spec)
    a = ch.airing(now)
    order = spec.get("order", "in_order")
    start_on = int(spec.get("start_on") or 0)
    if a:
        start = a["end"]
        era = ch.era_at(now)
        nxt = era.airing(a["end"]) if era else None
        follow = nxt["entry"]["id"] if nxt else None
    else:
        start = floor_to(now, start_on) if start_on else float(int(now))
        follow = None
    era = {"from": start, "lineup": lineup, "seed": spec.get("seed", 0), "order": order, "run": int(spec.get("run") or 1),
           "start_on": start_on, "break_seconds": int(spec.get("break_seconds") or 0), "skip": 0}
    if follow and lineup:
        first = cycle_order(lineup, order, era["run"], era["seed"], 0)
        where = {lineup[i]["id"]: k for k, i in enumerate(first)}
        era["skip"] = where.get(follow, 0)
    keep = [e for e in spec.get("eras") or [] if float(e["from"]) < start]
    # Drop eras that a later one replaced over a day ago: they can never be asked about again.
    while len(keep) > 1 and float(keep[1]["from"]) < now - 86400:
        keep.pop(0)
    return keep + [era]


def lineup_hash(lineup):
    return hashlib.sha256("|".join(f"{e['id']}:{round(float(e['dur']), 1)}" for e in lineup).encode()).hexdigest()[:16]


# Breaks -------------------------------------------------------------------------------------------------------------
MID_LEAST = 20.0  # a break inside a programme shorter than this (bumpers and clips) is left out (0.4.0)
END_ROOM = 15.0  # the end break keeps at least this, past its bumpers and ident, when breaks inside take their time


def _pick(items, rng, last=None):
    choice = [c for c in items if c.get("id") != last] or items
    return choice[rng.below(len(choice))]


def plan_break(airing, after, clips, options):
    """The pieces that fill the gap between a programme's end and the next slot. The same airing always gets the same
    break.

    after:   the next few airings (the first is the programme after this one), for the cards
    clips:   {"idents": [...], "fillers": [...], "bumpers": [...], "sting": {...} or None, "random_idents": False,
             "holding": {...} or None}, each clip {"id", "dur", "title", "src"}; a promo filler also has "airs", when
             its programme starts
    options: {"ident_order": "in_order" | "random", "cards": True, "seed": ...}

    The order (owner, 19 November 2026, 0.4.0): a bumper opens the break; trailers, clips and promos; then the
    holding slide, looping to the tail (or Later and Coming up next cards, or a slate); a bumper closes the break; and
    one ident, with its music, plays immediately before the next programme. The ident comes from the idents (a pack's in a
    random order), else the pack's logo with music. When the gap is short the ident comes first, then both bumpers,
    then the rest. A promo is only shown before its programme has started.
    """
    t, end = airing["content_end"], airing["end"]
    gap = end - t
    out = []
    if gap < MIN_PIECE:
        return out
    slot_no = airing["slot_no"]
    rng = Rng(seed_of(options.get("seed", 0), "break", int(airing["start"]), slot_no))
    holding = clips.get("holding")
    idents = [c for c in clips.get("idents") or [] if c.get("dur", 0) > 0]
    fillers = [c for c in clips.get("fillers") or [] if c.get("dur", 0) > 0 and float(c.get("airs") or end + 1) > end]
    bumpers = [c for c in clips.get("bumpers") or [] if c.get("dur", 0) > 0]
    sting = clips.get("sting") if clips.get("sting") and float(clips["sting"].get("dur") or 0) > 0 else None

    # The tail first: the ident immediately before the programme, then the bumpers round the break.
    ident = None
    if idents:
        in_order = options.get("ident_order", "in_order") == "in_order" and not clips.get("random_idents")
        ident = idents[slot_no % len(idents)] if in_order else idents[rng.below(len(idents))]
    elif sting:
        ident = sting
    if ident and float(ident["dur"]) > gap:
        ident = None
    room = gap - (float(ident["dur"]) if ident else 0.0)
    opening = closing = None
    if bumpers:
        opening = _pick(bumpers, rng)
        closing = _pick(bumpers, rng, opening["id"])
        if float(opening["dur"]) + float(closing["dur"]) > room:
            opening = closing = None
    tail = (float(closing["dur"]) if closing else 0.0) + (float(ident["dur"]) if ident else 0.0)
    stop = end - tail  # where the middle of the break ends
    cards = bool(options.get("cards", True)) and bool(after) and not holding
    reserve = min(CARD_SECONDS, max(0.0, stop - t)) if cards else 0.0

    def add(kind, dur, **more):
        nonlocal t
        out.append({"kind": kind, "start": t, "end": t + dur, **more})
        t += dur

    if opening:
        add("clip", float(opening["dur"]), clip=opening, role="bumper")
    last = None
    while fillers:
        fits = [c for c in fillers if c["dur"] <= stop - t - reserve and (c["id"] != last or len(fillers) == 1)]
        if not fits:
            break
        c = fits[rng.below(len(fits))]
        add("clip", float(c["dur"]), clip=c, role="filler")
        last = c["id"]
    left = stop - t
    if left >= MIN_PIECE:
        if holding:
            add("holding", left, holding=holding, airing=after[0] if after else None)
        elif not cards:
            add("slate", left)
        else:
            # Later cards first, each for a programme after the next one, then Coming up next for the rest.
            later = list(after[1:])
            k = 0
            while left > CARD_MAX and later:
                add("card", min(CARD_MAX, left - CARD_SECONDS), card="later", airing=later[k % len(later)])
                k += 1
                left = stop - t
            while left > CARD_MAX * 2:  # nothing later to show: Coming up next again, in turns
                add("card", CARD_MAX, card="next", airing=after[0])
                left = stop - t
            add("card", left, card="next", airing=after[0])
    elif out and left > 0:
        out[-1]["end"] = stop
        t = stop
    elif left > 0 and not out:
        t = stop  # under a second before the tail: a short pause at the end of the programme
    if closing:
        add("clip", float(closing["dur"]), clip=closing, role="bumper")
    if ident:
        add("clip", float(ident["dur"]), clip=ident, role="ident")
    if out:
        out[-1]["end"] = end
    return out


def plan_mid_break(t, most, clips, seed):
    """A break inside a programme (0.4.0), from t for at most `most` seconds: a bumper, trailers, clips and promos
    that fit, and a bumper; no cards and no holding slide. Empty when no clip fits, so the programme carries on."""
    rng = Rng(seed)
    end = t + most
    fillers = [c for c in clips.get("fillers") or [] if c.get("dur", 0) > 0 and float(c.get("airs") or end + 1) > end]
    bumpers = [c for c in clips.get("bumpers") or [] if c.get("dur", 0) > 0]
    opening = _pick(bumpers, rng) if bumpers else None
    closing = _pick(bumpers, rng, opening["id"]) if bumpers else None
    ends = (float(opening["dur"]) + float(closing["dur"])) if bumpers else 0.0
    picked, used, last = [], 0.0, None
    while fillers:
        fits = [c for c in fillers if c["dur"] <= most - ends - used and (c["id"] != last or len(fillers) == 1)]
        if not fits:
            break
        c = fits[rng.below(len(fits))]
        picked.append(c)
        used += float(c["dur"])
        last = c["id"]
    if not picked:
        return []
    out = []
    for c, role in ([(opening, "bumper")] if opening else []) + [(c, "filler") for c in picked] + ([(closing, "bumper")] if closing else []):
        out.append({"kind": "clip", "start": t, "end": t + float(c["dur"]), "clip": c, "role": role, "mid": True})
        t += float(c["dur"])
    return out


def pieces_at(channel, t, clips, options, look=3):
    """Everything that plays in the slot on air at t: the programme, then its break pieces.

    options may also have (0.4.0) "breaks_in": a function of an entry giving the seconds into it where a break may go,
    and "mid_seconds": how long each break inside a programme may be (0, none). The programme is then played in
    parts, {"kind": "programme", "offset": seconds into it, "length": its running time}, with a break between; their
    time comes from the end break, so the slot, and the schedule, never move."""
    a = channel.airing(t)
    if not a:
        return None, []
    after, s = [], a["end"]
    for _ in range(look):
        n = channel.airing(s)
        if not n:
            break
        after.append(n)
        s = n["end"]
    length = a["content_end"] - a["start"]
    parts, mids = split_programme(a, clips, options)
    pieces = []
    t0 = a["start"]
    for (o0, o1), mid in zip(parts, mids + [[]]):
        pieces.append({"kind": "programme", "start": t0, "end": t0 + (o1 - o0), "airing": a, "offset": o0, "length": length})
        t0 += o1 - o0
        pieces += mid
        if mid:
            t0 = mid[-1]["end"]
    pieces += plan_break({**a, "content_end": t0}, after, clips, options)
    return a, pieces


def split_programme(a, clips, options):
    """Where a programme is played in parts (0.4.0): ([(from, to) seconds into it, ...], [the break after each part
    but the last]). One part, the whole programme, unless breaks inside programmes are chosen, points are known, and
    the end break has the time."""
    length = a["content_end"] - a["start"]
    whole = ([(0.0, length)], [])
    most = float(options.get("mid_seconds") or 0)
    find = options.get("breaks_in")
    if most <= 0 or not find or length <= 0:
        return whole
    points = sorted(p for p in (find(a["entry"]) or []) if 60 < p < length - 60)
    if not points:
        return whole
    # The end break keeps room for its bumpers, its ident and a little more; the rest may go inside.
    bumper = max([float(c.get("dur") or 0) for c in clips.get("bumpers") or []] or [0.0])
    ident = max([float(c.get("dur") or 0) for c in clips.get("idents") or []] or [float((clips.get("sting") or {}).get("dur") or 0)])
    spare = (a["end"] - a["content_end"]) - (2 * bumper + ident + END_ROOM)
    parts, mids, at, taken = [], [], 0.0, 0.0
    for p in points:
        give = min(most, spare)
        if give < MID_LEAST:
            break
        mid = plan_mid_break(a["start"] + p + taken, give, clips, seed_of(options.get("seed", 0), "mid", int(a["start"]), int(p)))
        if not mid:
            continue
        parts.append((at, p))
        mids.append(mid)
        took = mid[-1]["end"] - mid[0]["start"]
        spare -= took
        taken += took
        at = p
    if not mids:
        return whole
    parts.append((at, length))
    return parts, mids
